import * as winston from "winston";
export const log: winston.Winston = require("winston-color");
