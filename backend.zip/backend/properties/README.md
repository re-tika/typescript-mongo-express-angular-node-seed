# This is secret data!

As soon as you insert your credentials, do the following steps:

- Uncomment the #properties comment in the .gitignore file (removing the #).
- Run `git rm --cached -r ./properties` from the backend-project-root.

